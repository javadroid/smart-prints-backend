import { Injectable, HttpException, HttpStatus } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import axios from "axios";
import * as crypto from "crypto";

@Injectable()
export class PaystackService {
  private readonly baseUrl: string;
  private readonly secretKey: string;
  private readonly secretHash: string;
  private readonly headers: any;

  constructor(private configService: ConfigService) {
    this.baseUrl = "https://api.paystack.co"; // Base URL for Paystack API
    this.secretKey = this.configService.get<string>("PAYSTACK_SECRET_KEY");
    this.secretHash = this.configService.get<string>("PAYSTACK_ENCRYPTION_KEY");
    this.headers = {
      accept: "application/json",
      Authorization: `Bearer ${this.secretKey}`,
      "Content-Type": "application/json",
    };
  }

  /**
   * Creates a payment link using Paystack's API
   */
  async createPaymentLink(data: {
    amount: number;
    email: string;
    currency?: string;
    callback_url?: string;
    metadata?: any;
  }) {
    try {
      const response = await axios.post(
        `${this.baseUrl}/transaction/initialize`,
        {
          amount: data.amount * 100, // Paystack expects amount in kobo
          email: data.email,
          currency: data.currency || "NGN",
          callback_url: data.callback_url,
          metadata: data.metadata,
        },
        { headers: this.headers }
      );

      return response.data;
    } catch (error) {
      throw new HttpException(
        error?.response?.data || "Failed to create payment link",
        error?.response?.status || HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }

  /**
   * Verifies the status of a payment using Paystack's API
   */
  async verifyPaymentLink(reference: string) {
    try {
      const response = await axios.get(
        `${this.baseUrl}/transaction/verify/${reference}`,
        { headers: this.headers }
      );

      return response.data;
    } catch (error) {
      throw new HttpException(
        error?.response?.data || "Failed to verify payment",
        error?.response?.status || HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }

  /**
   * Validates and handles Paystack webhook
   */
  async handleWebhook(req: any): Promise<any> {
    try {
      const hash = crypto
        .createHmac("sha512", this.secretKey)
        .update(JSON.stringify(req.body))
        .digest("hex");

      if (hash !== req.headers["x-paystack-signature"]) {
        throw new Error("Invalid signature");
      }

      return req.body;
    } catch (error) {
        console.error("Paystack webhook error", error);
        throw new HttpException(
            "Invalid webhook signature",
            HttpStatus.BAD_REQUEST
        );
    }
  }

  // paystack get all banks
  async getPaystackBanks() {
    const response = await axios.get('https://api.paystack.co/bank', {
      headers: {
        'Authorization': `Bearer ${this.secretKey}`,
        'Content-Type': 'application/json',
      },
    });
    return response.data;
  }

  // paystack verify account number
  async verifyPaystackAccountNumber(accountNumber: string, bankCode: string) {
    const response = await axios.get(`https://api.paystack.co/bank/resolve?account_number=${accountNumber}&bank_code=${bankCode}`, {
      headers: {
        'Authorization': `Bearer ${this.secretKey}`,
        'Content-Type': 'application/json',
      },
    });
    return response.data;
  }
}
